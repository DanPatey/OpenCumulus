class CreateReservations < ActiveRecord::Migration
  def change
    create_table :reservations do |t|
      t.string :name
      t.string :primary_contact
      t.string :home_base
      t.string :operated_under
      t.string :plane_ac_type
      t.string :plane_flt
      t.string :plane_fuel_type
      t.integer :plane_number_pax
      t.datetime :departure_at
      t.datetime :arrival_at
      t.string :departure_fuel_type
      t.string :departure_fuel_units
      t.boolean :departure_prist
      t.decimal :departure_fuel_quantity
      t.string :arrival_fuel_type
      t.string :arrival_fuel_units
      t.boolean :arrival_prist
      t.decimal :arrival_fuel_quantity

      t.timestamps null: false
    end
  end
end
