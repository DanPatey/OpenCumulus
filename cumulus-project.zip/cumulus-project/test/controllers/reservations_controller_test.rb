require 'test_helper'

class ReservationsControllerTest < ActionController::TestCase
  setup do
    @reservation = reservations(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:reservations)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create reservation" do
    assert_difference('Reservation.count') do
      post :create, reservation: { arrival_at: @reservation.arrival_at, arrival_fuel_quantity: @reservation.arrival_fuel_quantity, arrival_fuel_type: @reservation.arrival_fuel_type, arrival_fuel_units: @reservation.arrival_fuel_units, arrival_prist: @reservation.arrival_prist, departure_at: @reservation.departure_at, departure_fuel_quantity: @reservation.departure_fuel_quantity, departure_fuel_type: @reservation.departure_fuel_type, departure_fuel_units: @reservation.departure_fuel_units, departure_prist: @reservation.departure_prist, home_base: @reservation.home_base, name: @reservation.name, operated_under: @reservation.operated_under, plane_ac_type: @reservation.plane_ac_type, plane_flt: @reservation.plane_flt, plane_fuel_type: @reservation.plane_fuel_type, plane_number_pax: @reservation.plane_number_pax, primary_contact: @reservation.primary_contact }
    end

    assert_redirected_to reservation_path(assigns(:reservation))
  end

  test "should show reservation" do
    get :show, id: @reservation
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @reservation
    assert_response :success
  end

  test "should update reservation" do
    patch :update, id: @reservation, reservation: { arrival_at: @reservation.arrival_at, arrival_fuel_quantity: @reservation.arrival_fuel_quantity, arrival_fuel_type: @reservation.arrival_fuel_type, arrival_fuel_units: @reservation.arrival_fuel_units, arrival_prist: @reservation.arrival_prist, departure_at: @reservation.departure_at, departure_fuel_quantity: @reservation.departure_fuel_quantity, departure_fuel_type: @reservation.departure_fuel_type, departure_fuel_units: @reservation.departure_fuel_units, departure_prist: @reservation.departure_prist, home_base: @reservation.home_base, name: @reservation.name, operated_under: @reservation.operated_under, plane_ac_type: @reservation.plane_ac_type, plane_flt: @reservation.plane_flt, plane_fuel_type: @reservation.plane_fuel_type, plane_number_pax: @reservation.plane_number_pax, primary_contact: @reservation.primary_contact }
    assert_redirected_to reservation_path(assigns(:reservation))
  end

  test "should destroy reservation" do
    assert_difference('Reservation.count', -1) do
      delete :destroy, id: @reservation
    end

    assert_redirected_to reservations_path
  end
end
