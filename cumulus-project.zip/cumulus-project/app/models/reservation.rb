class Reservation < ActiveRecord::Base
end
