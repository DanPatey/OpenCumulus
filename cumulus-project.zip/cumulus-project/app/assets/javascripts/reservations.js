$(document).ready(function() {
  var $currentPane = $('.form-pane.form-pane-active'),
    currentStep = 1;
  
  $('.form-pane-next').on('click', function(ev) {
    ev.preventDefault();
    showPane(currentStep + 1);
  });
  
  $('.form-pane-last').on('click', function(ev) {
    ev.preventDefault();
    showPane(currentStep - 1);
  });
  
  function showPane(step) {
    var $pane = $('.form-pane[step="' + step + '"]');
    $currentPane.removeClass('form-pane-active');
    $pane.addClass('form-pane-active');
    setCurrentPane($pane);
  }
  
  function setCurrentPane($pane) {
    $currentPane = $pane;
    currentStep = parseInt($currentPane.attr('step'));
  }
});