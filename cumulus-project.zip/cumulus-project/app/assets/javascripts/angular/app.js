angular.module('cumulus', ['templates', 'ui.router'])

	.config(['$httpProvider', function ($httpProvider) {
		var csrfToken = $('meta[name=csrf-token]').attr('content');
		$httpProvider.defaults.headers.common['X-CSRF-Token'] = csrfToken;
	}])

	.config(function ($stateProvider, $urlRouterProvider) {
		$stateProvider
			.state('register', {
				url: '/register',
				templateUrl: 'angular/templates/form.html',
				controller: 'formController'
			})

			.state('register.info', {
				url: '/info',
				templateUrl: 'angular/templates/form-info.html'
			})

			.state('register.departure', {
				url: '/departure',
				templateUrl: 'angular/templates/form-departure.html'
			})

			.state('register.arrival', {
				url: '/arrival',
				templateUrl: 'angular/templates/form-arrival.html'
			})

			.state('register.plane', {
				url: '/plane',
				templateUrl: 'angular/templates/form-plane.html'
			})

			.state('register.departureSupport', {
				url: '/departureSupport',
				templateUrl: 'angular/templates/form-departure-support.html'
			})

			.state('register.arrivalSupport', {
				url: '/arrivalSupport',
				templateUrl: 'angular/templates/form-arrival-support.html'
			})

			.state('register.summary', {
				url: '/summary',
				templateUrl: 'angular/templates/form-summary.html'
			})

			.state('register.checkout', {
				url: '/checkout',
				templateUrl: 'angular/templates/form-checkout.html'
			})

			.state('register.complete', {
				url: '/complete',
				templateUrl: 'angular/templates/form-complete.html'
			})
			$urlRouterProvider.otherwise('/register/info');
	});
