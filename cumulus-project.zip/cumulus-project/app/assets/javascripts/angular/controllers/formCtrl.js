var formController = function ($scope, $state) {
	$scope.greet = 'hello';
	console.log($scope.greet);
	$scope.reservation = {
		departureDate: new Date(),
		departureTime: new Date(1970,0,1, 12,0,0),
		arrivalDate: new Date(),
		arrivalTime: new Date(1970,0,1,13,0,0),
		arrivalServices: {
			crewCarNum: 1,
			rentalCarNum: 1
		},
		departureServices: {
			crewCarNum: 1,
			rentalCarNum: 1
		}
	};

	$scope.goTo = function (state) {
		$state.go(state);
	}

	$scope.airports = [
		"ANC - Anchorage, AK",
		"APA - Denver, CO",
		"AUS - Austin, TX",
		"BCT - Boca Raton, FL",
		"BDL - Hartford, CT",
		"BED - Bedford, MA",
		"BFM - Mobile, AL",
		"BNA - Nashville, TN",
		"BOS - Boston, MA",
		"BQH - London, Biggin Hill",
		"BWI - Baltimore, MD",
		"BZN - Belgrade, MT",
		"CRP - Corpus Christi, TX",
		"DAB - Daytona Beach, FL",
		"DAL - Dallas, TX",
		"DCA - Washington, DC",
		"DEN - Denver, CO",
		"DSM - Des Moines, IA",
		"EWR - Newark, NJ",
		"FAT - Fresno, CA",
		"FLL - Fort Lauderdale, FL",
		"FRA - Frankfurt-Airport, Germany",
		"FTW - Fort Worth, TX",
		"FTY - Atlanta, GA",
		"GRB - Green Bay, WI",
		"HOU - Houston, TX",
		"HPN - White Plans, NY",
		"HSV - Huntsville, AL",
		"HXD - Hilton Head, SC",
		"IAD - Washington, Virginia",
		"ICT - Wichita, Kansas",
		"IND - Indianapolis, IN",
		"ISM - Kissimmee, FL",
		"IXD - New Century, KS",
		"JAX - Jacksonville, FL",
		"LAS - Las Vegas, NV",
		"LGB - Long Beach, CA",
		"MCI - Kansas City, MO",
		"MCO - Orlando, FL",
		"MDW - Chicago - Midway, IL",
		"MEM - Memphis, TN",
		"MKC - Kansas City, MO",
		"MKE - Milwaukee, WI",
		"MMU - Morristown, NJ",
		"MOB - Mobile, AL",
		"MSP - Minneapolis, MN",
		"MSY - Kenner, LA",
		"OMA - Omaha, NE",
		"ORD - Chicago, IL",
		"PBI - West Palm Beach, FL",
		"PDK - Atlanta, GA",
		"PIE - Clearwater, FL",
		"PLS - Providenciales, Turks and Caicos",
		"PSP - Palm Springs, CA",
		"PWK - Palwaukee, IL",
		"RST - Rochester, MN",
		"SAT - San Antonion, TX",
		"SAV - Savannah, GA",
		"SBA - Goleta, CA",
		"SDL - Scottsdale, AZ",
		"SFO - San Francisco, CA",
		"SIG - San Juan, PR",
		"SJC - San Jose, CA",
		"SNA - Santa Ana, CA",
		"STL - St. Louis, MO",
		"STP - St. Paul, MN",
		"SXF - Berlin Schonefeld, Germany",
		"TEB - Teterboro, NJ",
		"TRM - Thermal, CA",
		"VNY - Van Nuys, CA",
		"YVR - Richmond, British Columbia",
		"CYUL - Montreal, Quebec"
	];

	$scope.parseCode = function(airportString) {
		if (angular.isDefined(airportString)) {
			return airportString.match(/([A-Z]{3})/)[0];
		} else {
			return "N/A";			
		}
	}

	$scope.friendlyDate = function (date) {
		var day = date.getDate();
		var month = date.getMonth() + 1;
		var year = date.getFullYear();
		return month + "/" + day + "/" + year;
	}

	$scope.friendlyTime = function (time) {
		var hours = time.getHours();
		var minutes = time.getMinutes();
		var amPm = "am";
		if (hours === 12) {
			amPm = "pm";
		}
		if (hours > 12) {
			hours = hours % 12;
			amPm = "pm";
		}
		if (minutes < 10) {
			minutes = "0" + minutes;
		}
		return hours + ":" + minutes + amPm;
	}

	$scope.processForm = function() {
		$state.go('register.complete');
	}
};

angular.module('cumulus').controller('formController', ['$scope', '$state', formController]);