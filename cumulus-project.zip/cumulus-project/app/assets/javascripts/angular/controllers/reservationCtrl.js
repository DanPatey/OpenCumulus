angular.module('cumulus').controller('ReservationCtrl', ['$scope', function ($scope) {
	$scope.greeting = "hello";
}]);